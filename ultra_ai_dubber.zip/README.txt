
ULTRA AI VIDEO DUBBER

How to Run:

1. Install FFmpeg (required)

2. Install Python packages:
pip install -r requirements.txt

3. Start server:
uvicorn main:app --reload

4. Open browser:
http://127.0.0.1:8000
