
import whisper
import subprocess
from googletrans import Translator
import edge_tts
import asyncio
from moviepy.editor import VideoFileClip, AudioFileClip

model = whisper.load_model("base")

async def generate_tts(text, output_file, voice="en-US-GuyNeural"):
    communicate = edge_tts.Communicate(text, voice)
    await communicate.save(output_file)

def extract_audio(video, audio="audio.wav"):
    subprocess.run([
        "ffmpeg","-y","-i",video,"-vn",
        "-acodec","pcm_s16le","-ar","44100","-ac","2",audio
    ])

def dub_video(input_video, target_lang="hi"):

    extract_audio(input_video)

    result = model.transcribe("audio.wav")
    text = result["text"]

    translator = Translator()
    translated = translator.translate(text, dest=target_lang).text

    asyncio.run(generate_tts(translated, "tts.mp3"))

    video = VideoFileClip(input_video)
    new_audio = AudioFileClip("tts.mp3")

    final = video.set_audio(new_audio)

    output = "outputs/dubbed.mp4"
    final.write_videofile(output)

    return output
